// File Location: src/app/api/auth/[...nextauth]/route.ts

import { handlers } from "../../../auth" // Nayi auth.ts file se import karein
export const { GET, POST } = handlers