"use client";

import { useState, useEffect, useTransition, Fragment, useCallback } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { toast } from "react-hot-toast";
import { PlusCircle, Edit, Trash2, X, Loader2, Search, ChevronLeft, ChevronRight } from "lucide-react";
import { Dialog, Transition } from '@headlessui/react';
import { Category, upsertCategory, deleteCategory } from "../_actions/categoryActions";
import slugify from "slugify";

// --- Debounce Hook ---
function useDebounce(value: string, delay: number) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

// --- Category Form Modal Component ---
function CategoryFormModal({ isOpen, onClose, category, allCategories }: { isOpen: boolean; onClose: () => void; category: Partial<Category> | null; allCategories: Category[]; }) {
  const [isPending, startTransition] = useTransition();
  const isEditMode = !!category?._id;

  const [name, setName] = useState(category?.name || '');
  const [slug, setSlug] = useState(category?.slug?.current || '');

  useEffect(() => {
      setName(category?.name || '');
      setSlug(category?.slug?.current || '');
  }, [category]);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newName = e.target.value;
      setName(newName);
      setSlug(slugify(newName, { lower: true, strict: true }));
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    formData.set('name', name);
    formData.set('slug', slug);

    startTransition(async () => {
      const result = await upsertCategory(formData);
      if (result.success) {
        toast.success(result.message);
        onClose();
      } else {
        toast.error(result.message);
      }
    });
  };

  if (!isOpen) return null;

  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
          <div className="fixed inset-0 bg-black/50" />
        </Transition.Child>
        <div className="fixed inset-0 overflow-y-auto"><div className="flex min-h-full items-center justify-center p-4">
          <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0 scale-95" enterTo="opacity-100 scale-100" leave="ease-in duration-200" leaveFrom="opacity-100 scale-100" leaveTo="opacity-0 scale-95">
            <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-lg bg-white dark:bg-gray-800 text-left align-middle shadow-xl transition-all">
              <form onSubmit={handleSubmit}>
                <div className="p-6">
                  <div className="flex justify-between items-center pb-4 border-b dark:border-gray-700">
                    <Dialog.Title as="h3" className="text-xl font-bold text-gray-900 dark:text-gray-100">{isEditMode ? "Edit Category" : "Add New Category"}</Dialog.Title>
                    <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"><X size={20}/></button>
                  </div>
                  <div className="mt-4 space-y-4">
                    {isEditMode && <input type="hidden" name="id" value={category?._id} />}
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label><input type="text" name="name" value={name} onChange={handleNameChange} className="mt-1 w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md" required /></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Slug</label><input type="text" name="slug" value={slug} readOnly className="mt-1 w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-100 dark:bg-gray-700"/></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Parent Category</label><select name="parentId" defaultValue={category?.parent?._id} className="mt-1 w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md"><option value="">-- No Parent --</option>{allCategories.filter(c => c._id !== category?._id).map(cat => (<option key={cat._id} value={cat._id}>{cat.name}</option>))}</select></div>
                  </div>
                </div>
                <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end gap-4">
                  <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 font-semibold rounded-md">Cancel</button>
                  <button type="submit" disabled={isPending} className="flex items-center justify-center gap-2 px-4 py-2 bg-brand-primary text-white font-semibold rounded-md disabled:bg-opacity-70">
                    {isPending && <Loader2 className="animate-spin" size={18}/>}
                    {isPending ? (isEditMode ? 'Updating...' : 'Creating...') : (isEditMode ? "Update" : "Create")}
                  </button>
                </div>
              </form>
            </Dialog.Panel>
          </Transition.Child>
        </div></div>
      </Dialog>
    </Transition>
  );
}

// --- Pagination Component ---
function Pagination({ totalPages, currentPage, onPageChange, isPending }: { totalPages: number; currentPage: number; onPageChange: (page: number) => void; isPending: boolean; }) {
    return (
        <nav className="flex items-center justify-center gap-4 mt-8">
            <button onClick={() => onPageChange(currentPage - 1)} disabled={currentPage <= 1 || isPending} className="flex items-center gap-1 text-sm font-semibold disabled:opacity-50"><ChevronLeft size={16}/> Previous</button>
            <span className="text-sm">Page {currentPage} of {totalPages}</span>
            <button onClick={() => onPageChange(currentPage + 1)} disabled={currentPage >= totalPages || isPending} className="flex items-center gap-1 text-sm font-semibold disabled:opacity-50">Next <ChevronRight size={16}/></button>
        </nav>
    )
}

// --- Main Client Page ---
export default function CategoriesClientPage({
  initialCategories,
  initialTotalPages,
}: {
  initialCategories: Category[];
  initialTotalPages: number;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [isPending, startTransition] = useTransition();

  const currentPage = Number(searchParams.get("page")) || 1;
  const currentSearch = searchParams.get("search") || "";

  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);
  const [searchTerm, setSearchTerm] = useState(currentSearch);
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  useEffect(() => {
    setCategories(initialCategories);
  }, [initialCategories]);
  
  useEffect(() => {
    if (debouncedSearchTerm !== currentSearch) {
        const params = new URLSearchParams(searchParams.toString());
        params.set('page', '1');
        if (debouncedSearchTerm) {
            params.set("search", debouncedSearchTerm);
        } else {
            params.delete("search");
        }
        startTransition(() => {
            router.push(`${pathname}?${params.toString()}`);
        });
    }
  }, [debouncedSearchTerm, currentSearch, pathname, router, searchParams]);
  
  const handlePageChange = (page: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set('page', page.toString());
    startTransition(() => {
      router.push(`${pathname}?${params.toString()}`);
    });
  };

  const handleAddNew = () => { setEditingCategory(null); setIsModalOpen(true); };
  const handleEdit = (category: Category) => { setEditingCategory(category); setIsModalOpen(true); };
  const handleDelete = async (category: Category) => {
    if (window.confirm(`Are you sure you want to delete "${category.name}"? This is irreversible.`)) {
      toast.loading("Deleting...");
      const result = await deleteCategory(category._id);
      toast.dismiss();
      if (result.success) {
        toast.success(result.message);
        router.refresh();
      } else {
        toast.error(result.message);
      }
    }
  };

  return (
    <div className={`transition-opacity ${isPending ? 'opacity-60 pointer-events-none' : 'opacity-100'}`}>
      <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-md border dark:border-gray-700">
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex-grow relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20}/>
            <input type="text" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by category name..."
              className="w-full p-2 pl-10 border rounded-md"
            />
          </div>
          <button onClick={handleAddNew} className="flex-shrink-0 flex items-center justify-center gap-2 px-4 py-2 bg-brand-primary text-on-primary font-semibold rounded-md hover:bg-brand-primary-hover">
            <PlusCircle size={20} /> Add New
          </button>
        </div>
        
        {/* Mobile View: Card List */}
        <div className="lg:hidden space-y-3">
          {categories.map((cat) => (
            <div key={cat._id} className="p-4 rounded-lg border bg-gray-50 dark:bg-gray-700/50 dark:border-gray-600">
              <div>
                <p className="font-bold text-gray-800 dark:text-gray-100">{cat.name}</p>
                <p className="text-xs font-mono text-gray-500">{cat.slug.current}</p>
              </div>
              <div className="mt-3 text-sm grid grid-cols-2">
                <div><p className="text-xs text-gray-500">Parent</p><p>{cat.parent?.name || "--"}</p></div>
                <div><p className="text-xs text-gray-500">Sub-categories</p><p>{cat.subCategoryCount}</p></div>
              </div>
              <div className="mt-3 border-t dark:border-gray-600 pt-2 flex justify-end items-center gap-4">
                <button onClick={() => handleEdit(cat)} className="p-1 text-blue-600 hover:text-blue-800"><Edit size={16} /></button>
                <button onClick={() => handleDelete(cat)} className="p-1 text-red-600 hover:text-red-800"><Trash2 size={16} /></button>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop View: Table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th className="p-3 text-left font-semibold text-gray-600 dark:text-gray-300">Name</th>
                <th className="p-3 text-left font-semibold text-gray-600 dark:text-gray-300">Parent</th>
                <th className="p-3 text-center font-semibold text-gray-600 dark:text-gray-300">Sub-Categories</th>
                <th className="p-3 text-center font-semibold text-gray-600 dark:text-gray-300">Products</th>
                <th className="p-3 text-right font-semibold text-gray-600 dark:text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {categories.map((cat) => (
                <tr key={cat._id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="p-3 font-medium text-gray-800 dark:text-gray-100">{cat.name}<p className="text-xs font-mono text-gray-500">{cat.slug.current}</p></td>
                  <td className="p-3 text-gray-600 dark:text-gray-400">{cat.parent?.name || "--"}</td>
                  <td className="p-3 text-center text-gray-600 dark:text-gray-400">{cat.subCategoryCount}</td>
                  <td className="p-3 text-center text-gray-600 dark:text-gray-400">{cat.productCount}</td>
                  <td className="p-3 text-right"><div className="flex justify-end items-center gap-4">
                    <button onClick={() => handleEdit(cat)} className="text-blue-600 hover:text-blue-800"><Edit size={16} /></button>
                    <button onClick={() => handleDelete(cat)} className="text-red-600 hover:text-red-800"><Trash2 size={16} /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {initialTotalPages > 1 && (
        <Pagination totalPages={initialTotalPages} currentPage={currentPage} onPageChange={handlePageChange} isPending={isPending}/>
      )}

      <CategoryFormModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} category={editingCategory} allCategories={categories} />
    </div>
  );
}