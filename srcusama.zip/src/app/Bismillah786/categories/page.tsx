import { getPaginatedCategories } from "./_actions/categoryActions";
import CategoriesClientPage from "./_components/CategoriesClientPage";
import { Suspense } from 'react';
import { ClipLoader } from "react-spinners";
import Link from "next/link";


// Correctly type the props for Next.js 15+ async pages
type AdminCategoriesPageProps = {
  searchParams: Promise<{ 
    page?: string;
    search?: string;
  }>;
}

// Data fetching component
async function CategoryList({ searchParams }: { searchParams: { page?: string; search?: string; } }) {
  const page = Number(searchParams.page) || 1;
  const searchTerm = searchParams.search || "";
  
  // Fetch initial paginated data on the server
  const { categories, totalPages } = await getPaginatedCategories({ 
    page, 
    searchTerm 
  });

  return (
    <CategoriesClientPage 
      initialCategories={categories} 
      initialTotalPages={totalPages} 
    />
  );
}

// Main page component
export default async function AdminCategoriesPage(props: AdminCategoriesPageProps) {
  const searchParams = await props.searchParams;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Manage Categories</h1>
        <div className="flex items-center gap-4">
          <Link href="/Bismillah786/categories/import" className="text-sm font-medium text-brand-primary hover:underline">
            Import from CSV
          </Link>
          {/* "Add New" button ki logic client component mein chali jayegi */}
        </div>
      </div>

      <Suspense
        key={`${searchParams.page}-${searchParams.search}`}
        fallback={
          <div className="flex justify-center items-center h-96 bg-white dark:bg-gray-800 rounded-lg shadow-md border dark:border-gray-700">
            <ClipLoader color="#F97316" size={50} />
          </div>
        }
      >
        <CategoryList searchParams={searchParams} />
      </Suspense>
    </div>
  );
}