"use client";

import { useState, useEffect } from "react";
import { getAnalyticsData } from "./_actions/analyticsActions";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { DollarSign, ShoppingCart, Users, TrendingUp } from "lucide-react";
import Link from "next/link";

// --- TYPE DEFINITIONS ---
interface SourceData {
  source: string;
  sales: number;
  orders: number;
}
interface SalesTrendData {
  name: string;
  sales: number;
}
interface TopProductData {
  productId: string;
  name: string;
  totalQuantity: number;
  totalSales: number;
}
interface AnalyticsData {
  salesBySource: SourceData[];
  overall: { totalSales: number; totalOrders: number };
  newUsers: number;
  salesTrend: SalesTrendData[];
  topProducts: TopProductData[];
}

// --- REUSABLE COMPONENTS ---
const StatCard = ({
  title,
  value,
  icon: Icon,
  color = "brand",
}: {
  title: string;
  value: string | number;
  icon: React.ElementType;
  color?: "brand" | "green" | "blue";
}) => {
  const colorClasses = {
    brand:
      "bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400",
    green:
      "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400",
    blue: "bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400",
  };
  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 flex items-center gap-4">
      <div className={`p-3 rounded-full ${colorClasses[color]}`}>
        <Icon size={24} />
      </div>
      <div>
        <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
        <p className="text-2xl font-bold text-gray-800 dark:text-gray-100">
          {value}
        </p>
      </div>
    </div>
  );
};

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#AF19FF"];
const ChartContainer = ({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 h-96">
    <h3 className="font-bold text-lg mb-4 text-gray-800 dark:text-gray-100">
      {title}
    </h3>
    {children}
  </div>
);

// --- MAIN PAGE COMPONENT ---
export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [days, setDays] = useState(30);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const analyticsData = await getAnalyticsData(days);
      setData(analyticsData);
      setLoading(false);
    };
    fetchData();
  }, [days]);

  if (loading) {
    // --- SKELETON LOADER ---
    return (
      <div className="space-y-8 animate-pulse">
        <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="h-28 bg-gray-200 dark:bg-gray-700 rounded-lg"
            ></div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {[...Array(2)].map((_, i) => (
            <div
              key={i}
              className="h-96 bg-gray-200 dark:bg-gray-700 rounded-lg"
            ></div>
          ))}
        </div>
        <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
      </div>
    );
  }
  if (!data)
    return (
      <p className="text-center text-gray-500">
        Could not load analytics data.
      </p>
    );

  return (
    <div className="space-y-8">
      {/* Header & Filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Growth Analytics
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Showing data for the last {days} days.
          </p>
        </div>
        <div className="flex items-center gap-2 p-1 bg-gray-200 dark:bg-gray-700 rounded-lg">
          {[7, 30, 90].map((d) => (
            <button
              key={d}
              onClick={() => setDays(d)}
              className={`px-4 py-1.5 text-sm font-semibold rounded-md transition-colors ${days === d ? "bg-white dark:bg-gray-800 text-brand-primary shadow" : "text-gray-600 dark:text-gray-300 hover:bg-white/50"}`}
            >
              Last {d}d
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard
          title="Total Sales"
          value={`Rs. ${data.overall.totalSales.toLocaleString()}`}
          icon={DollarSign}
          color="green"
        />
        <StatCard
          title="Total Orders"
          value={data.overall.totalOrders.toLocaleString()}
          icon={ShoppingCart}
          color="blue"
        />
        <StatCard
          title="New Customers"
          value={data.newUsers.toLocaleString()}
          icon={Users}
        />
      </div>

      {/* NEW: Sales Trend Chart */}
      <ChartContainer title="Sales Trend (Last 7 Days)">
        <ResponsiveContainer width="100%" height="90%">
          <BarChart
            data={data.salesTrend}
            margin={{ top: 5, right: 20, left: -15, bottom: 5 }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              vertical={false}
              stroke="var(--color-surface-border-darker)"
            />
            <XAxis
              dataKey="name"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              stroke="var(--color-text-subtle)"
            />
            <YAxis
              fontSize={12}
              tickLine={false}
              axisLine={false}
              stroke="var(--color-text-subtle)"
              tickFormatter={(value: number) => `Rs.${value / 1000}k`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "var(--color-surface-base)",
                border: "1px solid var(--color-surface-border-darker)",
                borderRadius: "0.5rem",
              }}
              cursor={{ fill: "rgb(var(--color-brand-primary) / 0.1)" }}
            />
            <Bar
              dataKey="sales"
              fill="var(--color-brand-primary)"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </ChartContainer>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <ChartContainer title="Sales by Source">
          <ResponsiveContainer width="100%" height="90%">
            <PieChart>
              <Tooltip />
              <Pie
                data={data.salesBySource}
                dataKey="sales"
                nameKey="source"
                cx="50%"
                cy="50%"
                outerRadius={80}
                labelLine={false}
                label={({
                  cx,
                  cy,
                  midAngle,
                  innerRadius,
                  outerRadius,
                  percent,
                }) => {
                  const radius =
                    innerRadius + (outerRadius - innerRadius) * 1.3;
                  const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                  const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                  return (
                    <text
                      x={x}
                      y={y}
                      fill="var(--color-text-secondary)"
                      textAnchor={x > cx ? "start" : "end"}
                      dominantBaseline="central"
                      fontSize={12}
                    >{`${(percent * 100).toFixed(0)}%`}</text>
                  );
                }}
              >
                {data.salesBySource.map((_, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </ChartContainer>
        <div className="lg:col-span-3 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="font-bold text-lg mb-4 text-gray-800 dark:text-gray-100">
            Orders & Sales by Source
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={data.salesBySource}
              margin={{ top: 5, right: 20, left: -10, bottom: 5 }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="var(--color-surface-border-darker)"
              />
              <XAxis
                dataKey="source"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                stroke="var(--color-text-subtle)"
              />
              <YAxis
                yAxisId="left"
                orientation="left"
                stroke="#00C49F"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#0088FE"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${v / 1000}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--color-surface-base)",
                  border: "1px solid var(--color-surface-border-darker)",
                  borderRadius: "0.5rem",
                }}
              />
              <Legend wrapperStyle={{ fontSize: "14px" }} />
              <Bar
                yAxisId="left"
                dataKey="orders"
                fill="#00C49F"
                name="Orders"
                radius={[4, 4, 0, 0]}
              />
              <Bar
                yAxisId="right"
                dataKey="sales"
                fill="#0088FE"
                name="Sales (Rs.)"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* NEW: Top Selling Products Table */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="font-bold text-lg mb-4 text-gray-800 dark:text-gray-100">
          Top Selling Products
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th className="p-3 text-left font-semibold text-gray-600 dark:text-gray-300">
                  Product
                </th>
                <th className="p-3 text-right font-semibold text-gray-600 dark:text-gray-300">
                  Quantity Sold
                </th>
                <th className="p-3 text-right font-semibold text-gray-600 dark:text-gray-300">
                  Total Sales (Rs.)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {data.topProducts.map((item) => (
                <tr
                  key={item.productId}
                  className="hover:bg-gray-50 dark:hover:bg-gray-700/50"
                >
                  <td className="p-3 font-medium text-gray-800 dark:text-gray-100">
                    <Link
                      href={`/Bismillah786/products/edit?id=${item.productId}`}
                      className="hover:underline"
                    >
                      {item.name}
                    </Link>
                  </td>
                  <td className="p-3 text-right font-semibold text-gray-700 dark:text-gray-300">
                    {item.totalQuantity.toLocaleString()}
                  </td>
                  <td className="p-3 text-right">
                    {item.totalSales.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
