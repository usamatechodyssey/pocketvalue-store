"use server";

import clientPromise from "@/app/lib/mongodb";
import { startOfDay, endOfDay, subDays, format } from 'date-fns';
import { ObjectId } from 'mongodb';

const DB_NAME = process.env.MONGODB_DB_NAME!;

// --- TYPE DEFINITIONS ---
interface SourceData { source: string; sales: number; orders: number; }
interface SalesTrendData { name: string; sales: number; }
interface TopProductData { productId: string; name: string; totalQuantity: number; totalSales: number; }

interface AnalyticsData {
  salesBySource: SourceData[];
  overall: { totalSales: number; totalOrders: number };
  newUsers: number;
  salesTrend: SalesTrendData[];
  topProducts: TopProductData[];
}

export async function getAnalyticsData(days: number = 30): Promise<AnalyticsData> {
  try {
    const client = await clientPromise;
    const db = client.db(DB_NAME);
    const ordersCollection = db.collection("orders");
    
    const endDate = new Date();
    const startDate = startOfDay(subDays(endDate, days));

    // --- 1. Overall Stats & Sales by Source (Optimized with a single aggregation) ---
    const mainPipeline = [
      { $match: { orderDate: { $gte: startDate, $lte: endDate }, status: { $ne: "Cancelled" } } },
      {
        $facet: {
          overallStats: [ { $group: { _id: null, totalSales: { $sum: "$totalPrice" }, totalOrders: { $sum: 1 } } } ],
          salesBySource: [
            { $group: { _id: "$trafficSource.source", totalSales: { $sum: "$totalPrice" }, totalOrders: { $sum: 1 } } },
            { $project: { _id: 0, source: { $ifNull: ["$_id", "direct"] }, sales: "$totalSales", orders: "$totalOrders" } },
            { $sort: { sales: -1 } }
          ],
        }
      }
    ];
    const mainAnalytics = await ordersCollection.aggregate(mainPipeline).toArray();
    const overall = mainAnalytics[0]?.overallStats[0] ? { totalSales: mainAnalytics[0].overallStats[0].totalSales, totalOrders: mainAnalytics[0].overallStats[0].totalOrders } : { totalSales: 0, totalOrders: 0 };
    const salesBySource = mainAnalytics[0]?.salesBySource || [];

    // --- 2. New Users Count (No change, it's perfect) ---
    const startTimestamp = Math.floor(startDate.getTime() / 1000).toString(16) + "0000000000000000";
    const startObjectId = new ObjectId(startTimestamp);
    const newUsers = await db.collection("users").countDocuments({ _id: { $gte: startObjectId } });

    // --- 3. NEW: Sales Trend (Last 7 Days) ---
    const salesTrendPipeline = [
        { $match: { orderDate: { $gte: startOfDay(subDays(new Date(), 6)), $lte: endOfDay(new Date()) }, status: { $ne: "Cancelled" } } },
        {
            $group: {
                _id: { $dateToString: { format: "%Y-%m-%d", date: "$orderDate" } },
                dailySales: { $sum: "$totalPrice" }
            }
        },
        { $sort: { _id: 1 } }
    ];
    const dailySales = await ordersCollection.aggregate(salesTrendPipeline).toArray();
    
    // Fill in missing days with 0 sales
    const salesTrend: SalesTrendData[] = [];
    for (let i = 6; i >= 0; i--) {
        const date = subDays(new Date(), i);
        const dateString = format(date, 'yyyy-MM-dd');
        const dayName = format(date, 'EEE'); // e.g., 'Mon'
        const found = dailySales.find(d => d._id === dateString);
        salesTrend.push({ name: dayName, sales: found?.dailySales || 0 });
    }

    // --- 4. NEW: Top Selling Products ---
    const topProductsPipeline = [
        { $match: { orderDate: { $gte: startDate, $lte: endDate }, status: { $ne: "Cancelled" } } },
        { $unwind: "$products" },
        {
            $group: {
                _id: "$products.productId",
                name: { $first: "$products.name" },
                totalQuantity: { $sum: "$products.quantity" },
                totalSales: { $sum: { $multiply: ["$products.price", "$products.quantity"] } }
            }
        },
        { $sort: { totalQuantity: -1 } },
        { $limit: 5 },
        { $project: { _id: 0, productId: "$_id", name: 1, totalQuantity: 1, totalSales: 1 } }
    ];
    const topProducts = await ordersCollection.aggregate(topProductsPipeline).toArray() as TopProductData[];

    return { salesBySource, overall, newUsers, salesTrend, topProducts };

  } catch (error) {
    console.error("Failed to fetch analytics data:", error);
    return { salesBySource: [], overall: { totalSales: 0, totalOrders: 0 }, newUsers: 0, salesTrend: [], topProducts: [] };
  }
}