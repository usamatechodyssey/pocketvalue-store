import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { SanityImageObject } from "@/sanity/types/product_types";
import {
  ArrowLeft,
  UserCircle,
  MapPin,
  CreditCard,
  Package,
  CheckCircle,
  AlertTriangle,
  X,
  Check,
} from "lucide-react";
import clientPromise from "@/app/lib/mongodb";
import { ObjectId } from "mongodb";
import { urlFor } from "@/sanity/lib/image";
import CopyButton from "../../_components/CopyButton";
import { getProductsStockStatus } from "@/sanity/lib/queries";
import UpdateOrderStatus from "../_components/UpdateOrderStatus";
import SendEmailModal from "../_components/SendEmailModal";

const DB_NAME = process.env.MONGODB_DB_NAME!;

interface OrderProduct {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: SanityImageObject;
  slug?: string;
  variant?: { key: string; name: string };
}
interface FullOrder {
  _id: ObjectId;
  userId: string;
  totalPrice: number;
  status: string;
  orderDate: Date;
  paymentMethod: string;
  paymentStatus: string;
  shippingAddress: {
    fullName: string;
    address: string;
    area: string;
    city: string;
    province: string;
    phone: string;
  };
  products: OrderProduct[];
  userDetails?: { name: string; email: string };
}

// StatusTimeline Component
const StatusTimeline = ({ status }: { status: string }) => {
  const statuses = ["Pending", "Processing", "Shipped", "Delivered"];
  const currentStatusIndex = statuses.indexOf(status);

  if (status === "Cancelled") {
    return (
      <div className="p-4 bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 rounded-lg text-center font-semibold flex items-center justify-center gap-2">
        <X size={18} /> This order has been cancelled.
      </div>
    );
  }

  return (
    <div className="relative pt-2 pb-8">
      <div className="absolute top-4 left-4 right-4 h-0.5 bg-gray-200 dark:bg-gray-700" />
      <div className="relative flex justify-between">
        {statuses.map((s, index) => (
          <div
            key={s}
            className="relative flex flex-col items-center text-center w-1/4"
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center border-2 z-10 transition-all duration-300 ${index <= currentStatusIndex ? "bg-brand-primary border-brand-primary" : "bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600"}`}
            >
              {index <= currentStatusIndex && (
                <Check className="h-5 w-5 text-white" />
              )}
            </div>
            <p
              className={`mt-2 text-xs font-semibold whitespace-nowrap ${index <= currentStatusIndex ? "text-brand-primary" : "text-gray-500 dark:text-gray-400"}`}
            >
              {s}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

// Database function
async function getSingleOrder(orderId: string): Promise<FullOrder | null> {
  try {
    const client = await clientPromise;
    const db = client.db(DB_NAME);
    if (!ObjectId.isValid(orderId)) return null;
    const results = await db
      .collection("orders")
      .aggregate([
        { $match: { _id: new ObjectId(orderId) } },
        {
          $lookup: {
            from: "users",
            let: { userIdStr: "$userId" },
            pipeline: [
              {
                $match: {
                  $expr: { $eq: ["$_id", { $toObjectId: "$$userIdStr" }] },
                },
              },
            ],
            as: "userDetails",
          },
        },
        { $unwind: { path: "$userDetails", preserveNullAndEmptyArrays: true } },
      ])
      .toArray();
    return results[0] as FullOrder | null;
  } catch (error) {
    console.error("Failed to fetch single order:", error);
    return null;
  }
}

type OrderDetailPageProps = { params: Promise<{ orderId: string }> };

export default async function OrderDetailPage(props: OrderDetailPageProps) {
  const params = await props.params;
  const { orderId } = params;

  const order = await getSingleOrder(orderId);
  if (!order) {
    notFound();
  }

  const productIdsInOrder = order.products.map((p) => p.productId);
  const stockStatuses = await getProductsStockStatus(productIdsInOrder);
  const stockMap = new Map(stockStatuses.map((s) => [s._id, s]));
  const customerName =
    order.userDetails?.name || order.shippingAddress.fullName;
  const customerEmail = order.userDetails?.email || "N/A";

  return (
    <div className="space-y-8">
      <div>
        <Link
          href="/Bismillah786/orders"
          className="flex items-center gap-2 text-sm font-semibold text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-4"
        >
          <ArrowLeft size={16} /> Back to All Orders
        </Link>
        <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">
          Order Details
        </h1>
        <div className="flex items-center gap-2 mt-1">
          <p className="text-sm font-mono text-gray-500">
            #{order._id.toString().slice(-6).toUpperCase()}
          </p>
          <CopyButton textToCopy={order._id.toString()} />
          <span className="mx-2 text-gray-300 dark:text-gray-600">•</span>
          <span className="text-sm text-gray-500">
            {new Date(order.orderDate).toLocaleString("en-US", {
              dateStyle: "long",
              timeStyle: "short",
            })}
          </span>
        </div>
      </div>

      <div className="p-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm">
        <h2 className="font-bold text-lg mb-6 text-gray-800 dark:text-gray-200">
          Order Status
        </h2>
        <StatusTimeline status={order.status} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4 flex items-center gap-2">
              <Package size={22} /> Products in Order ({order.products.length})
            </h2>
            <div className="space-y-4 divide-y divide-gray-200 dark:divide-gray-700">
              {order.products.map((product) => {
                const liveStockInfo = stockMap.get(product.productId);
                const isProductInStock = liveStockInfo
                  ? product.variant
                    ? (liveStockInfo.variants?.find(
                        (v) => v._key === product.variant!.key
                      )?.inStock ?? false)
                    : liveStockInfo.inStock
                  : false;
                return (
                  <div
                    key={product.productId + (product.variant?.key || "")}
                    className="pt-4 first:pt-0"
                  >
                    <div className="flex items-center gap-4">
                      <div className="relative w-16 h-16 rounded-md overflow-hidden bg-gray-100 dark:bg-gray-900 flex-shrink-0">
                        <Image
                          src={urlFor(product.image).url()}
                          alt={product.name}
                          fill
                          sizes="64px"
                          className="object-contain"
                        />
                      </div>
                      <div className="flex-grow">
                        <Link
                          href={`/product/${product.slug}`}
                          target="_blank"
                          className="font-semibold text-gray-800 dark:text-gray-200 hover:text-brand-primary transition-colors line-clamp-2"
                        >
                          {product.name}
                        </Link>
                        {product.variant?.name && (
                          <p className="text-xs text-gray-500 bg-gray-100 dark:bg-gray-700 inline-block px-2 py-0.5 rounded mt-1 font-medium">
                            {product.variant.name}
                          </p>
                        )}
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                          Qty: {product.quantity} × Rs.{" "}
                          {product.price.toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="font-bold text-gray-800 dark:text-gray-200">
                          Rs.{" "}
                          {(product.price * product.quantity).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-end text-xs text-gray-500">
                      {liveStockInfo ? (
                        <span
                          className={`px-2 py-1 font-semibold rounded-full flex items-center gap-1.5 ${isProductInStock ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                        >
                          {isProductInStock ? (
                            <CheckCircle size={14} />
                          ) : (
                            <AlertTriangle size={14} />
                          )}
                          {isProductInStock
                            ? "Live: In Stock"
                            : "Live: Out of Stock"}
                        </span>
                      ) : (
                        <span className="px-2 py-1 font-semibold rounded-full bg-gray-100 text-gray-500">
                          Product Deleted
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <UpdateOrderStatus
            orderId={order._id.toString()}
            currentStatus={order.status}
          />
        </div>
        <div className="space-y-8 lg:sticky lg:top-24">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border dark:border-gray-700">
            <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-200 flex items-center gap-2">
              <UserCircle size={22} /> Customer Details
            </h2>
            <p className="font-bold text-gray-900 dark:text-gray-100">
              {customerName}
            </p>
            <a
              href={`mailto:${customerEmail}`}
              className="text-sm text-blue-600 hover:underline"
            >
              {customerEmail}
            </a>
            <address className="text-sm text-gray-600 dark:text-gray-300 mt-2 not-italic">
              {order.shippingAddress.address}, {order.shippingAddress.area}
              <br />
              {order.shippingAddress.city}, {order.shippingAddress.province}
              <br />
              Phone: {order.shippingAddress.phone}
            </address>
            <div className="mt-6 border-t dark:border-gray-700 pt-4">
              <SendEmailModal
                customerId={order.userId}
                customerName={customerName}
              />
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border dark:border-gray-700">
            <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-200 flex items-center gap-2">
              <CreditCard size={22} /> Payment Summary
            </h2>
            <div className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
              <div className="flex justify-between">
                <span>Payment Method:</span>{" "}
                <span className="font-semibold text-gray-900 dark:text-gray-100">
                  {order.paymentMethod}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Payment Status:</span>{" "}
                <span className="font-semibold text-gray-900 dark:text-gray-100">
                  {order.paymentStatus}
                </span>
              </div>
              <div className="border-t border-gray-200 dark:border-gray-700 mt-4 pt-4 flex justify-between font-bold text-base text-gray-900 dark:text-gray-100">
                <span>Total Amount:</span>{" "}
                <span>Rs. {order.totalPrice.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
