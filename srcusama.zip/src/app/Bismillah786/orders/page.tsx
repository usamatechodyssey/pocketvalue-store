import { getPaginatedOrders } from "./_actions/orderActions";
import OrdersClientPage from "./_components/OrdersClientPage";
import { Suspense } from 'react';
import { ClipLoader } from "react-spinners";

// Correctly type the props for Next.js 15+ async pages
type AdminOrdersPageProps = {
    searchParams: Promise<{ 
        page?: string;
        status?: string;
        search?: string;
    }>;
}

// Data fetching component
async function OrdersList({ searchParams }: { searchParams: { page?: string; status?: string; search?: string; } }) {
    const page = Number(searchParams.page) || 1;
    const status = searchParams.status || 'All';
    const searchTerm = searchParams.search || '';
    
    // Fetch initial data on the server
    const { orders, totalPages } = await getPaginatedOrders({ 
        page, 
        status, 
        searchTerm 
    });

    return (
        <OrdersClientPage 
            initialOrders={orders} 
            initialTotalPages={totalPages} 
        />
    );
}

// Main page component
export default async function AdminOrdersPage(props: AdminOrdersPageProps) {
    const searchParams = await props.searchParams;

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">
                Manage Orders
            </h1>
            <Suspense 
                key={`${searchParams.page}-${searchParams.status}-${searchParams.search}`}
                fallback={
                    <div className="flex justify-center items-center h-96 bg-white dark:bg-gray-800 rounded-lg shadow-md border dark:border-gray-700">
                        <ClipLoader color="#F97316" size={50} />
                    </div>
                }
            >
                <OrdersList searchParams={searchParams} />
            </Suspense>
        </div>
    );
}