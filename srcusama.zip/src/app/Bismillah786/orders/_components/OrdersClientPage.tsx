"use client";

import { useState, useEffect, useCallback, useTransition, Suspense } from "react";
import Link from "next/link";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { Search, Loader2 } from "lucide-react";

// Debounce hook
function useDebounce(value: string, delay: number) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

// Type Definition
interface Order {
  _id: string;
  totalPrice: number;
  status: string;
  orderDate: string;
  customerName: string;
  itemCount: number;
}

// Helper Function
const getStatusColor = (status: string) => {
  switch (status?.toLowerCase()) {
    case "delivered": return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300";
    case "shipped": return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300";
    case "processing": return "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300";
    case "cancelled": return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300";
    default: return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"; // Pending
  }
};

// Main Client Component
export default function OrdersClientPage({
  initialOrders,
  initialTotalPages,
}: {
  initialOrders: Order[];
  initialTotalPages: number;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [isPending, startTransition] = useTransition();

  const currentPage = Number(searchParams.get("page")) || 1;
  const currentStatus = searchParams.get("status") || "All";
  const currentSearchTerm = searchParams.get("search") || "";

  const [localSearchTerm, setLocalSearchTerm] = useState(currentSearchTerm);
  const debouncedSearchTerm = useDebounce(localSearchTerm, 500);

  // Update URL when debounced search term changes
  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1"); // Reset to page 1 on new search
    if (debouncedSearchTerm) {
      params.set("search", debouncedSearchTerm);
    } else {
      params.delete("search");
    }
    startTransition(() => {
        router.push(`${pathname}?${params.toString()}`);
    });
  }, [debouncedSearchTerm]);

  const handleFilterChange = (newStatus: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", "1"); // Reset to page 1 on filter change
    params.set("status", newStatus);
    startTransition(() => {
        router.push(`${pathname}?${params.toString()}`);
    });
  };

  const handlePageChange = (page: number) => {
      const params = new URLSearchParams(searchParams.toString());
      params.set("page", page.toString());
      startTransition(() => {
          router.push(`${pathname}?${params.toString()}`);
      });
  };

  const TABS = ["All", "Pending", "Processing", "Shipped", "Delivered", "Cancelled"];

  return (
    <div className={`transition-opacity ${isPending ? 'opacity-50' : 'opacity-100'}`}>
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border dark:border-gray-700 space-y-4">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-grow relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20}/>
            <input type="text" value={localSearchTerm} onChange={(e) => setLocalSearchTerm(e.target.value)}
              placeholder="Search by Order ID, Customer Name..."
              className="w-full p-2 pl-10 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-900 focus:ring-brand-primary focus:border-brand-primary"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 -mb-2">
            {TABS.map((tab) => (
              <button key={tab} onClick={() => handleFilterChange(tab)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md whitespace-nowrap transition-colors ${
                  currentStatus === tab ? "bg-brand-primary text-white shadow" : "bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile View: Card List */}
        <div className="lg:hidden space-y-3">
            {initialOrders.length > 0 ? initialOrders.map(order => (
                <div key={order._id} className="p-4 rounded-lg border bg-gray-50 dark:bg-gray-700/50 dark:border-gray-600">
                    <div className="flex justify-between items-start">
                        <div>
                            <p className="font-bold text-gray-800 dark:text-gray-100">{order.customerName}</p>
                            <p className="text-xs font-mono text-gray-500">#{order._id.slice(-6).toUpperCase()}</p>
                        </div>
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(order.status)}`}>{order.status}</span>
                    </div>
                    <div className="mt-4 flex justify-between items-end">
                        <div>
                            <p className="text-xs text-gray-500">{new Date(order.orderDate).toLocaleDateString()}</p>
                            <p className="font-bold text-lg text-gray-900 dark:text-white">Rs. {order.totalPrice.toLocaleString()}</p>
                        </div>
                        <Link href={`/Bismillah786/orders/${order._id}`} className="text-sm font-semibold text-brand-primary hover:underline">View</Link>
                    </div>
                </div>
            )) : <p className="text-center py-16 text-gray-500">No orders found.</p>}
        </div>
        
        {/* Desktop View: Table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th className="px-6 py-3 text-left font-semibold text-gray-600 dark:text-gray-300">Order ID</th>
                <th className="px-6 py-3 text-left font-semibold text-gray-600 dark:text-gray-300">Customer</th>
                <th className="px-6 py-3 text-left font-semibold text-gray-600 dark:text-gray-300">Date</th>
                <th className="px-6 py-3 text-center font-semibold text-gray-600 dark:text-gray-300">Items</th>
                <th className="px-6 py-3 text-right font-semibold text-gray-600 dark:text-gray-300">Total</th>
                <th className="px-6 py-3 text-center font-semibold text-gray-600 dark:text-gray-300">Status</th>
                <th className="px-6 py-3 text-center font-semibold text-gray-600 dark:text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {initialOrders.length > 0 ? (
                initialOrders.map((order) => (
                  <tr key={order._id}>
                    <td className="px-6 py-4 font-mono text-gray-500">#{order._id.slice(-6).toUpperCase()}</td>
                    <td className="px-6 py-4 font-medium text-gray-800 dark:text-gray-100">{order.customerName}</td>
                    <td className="px-6 py-4 text-gray-500">{new Date(order.orderDate).toLocaleDateString()}</td>
                    <td className="px-6 py-4 text-center text-gray-500">{order.itemCount}</td>
                    <td className="px-6 py-4 text-right text-gray-800 dark:text-gray-100 font-semibold">Rs. {order.totalPrice.toLocaleString()}</td>
                    <td className="px-6 py-4 text-center"><span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(order.status)}`}>{order.status}</span></td>
                    <td className="px-6 py-4 text-center"><Link href={`/Bismillah786/orders/${order._id}`} className="font-semibold text-brand-primary hover:underline">View</Link></td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan={7} className="text-center py-16 text-gray-500">No orders found for this filter.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Pagination Controls */}
      {initialTotalPages > 1 && (
        <div className="mt-6 flex justify-center">
            <nav className="flex items-center gap-2">
                {Array.from({ length: initialTotalPages }, (_, i) => i + 1).map((page) => (
                    <button key={page} onClick={() => handlePageChange(page)}
                        className={`w-9 h-9 rounded-md text-sm font-medium transition-colors ${
                            currentPage === page
                            ? "bg-brand-primary text-white"
                            : "bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border dark:border-gray-600"
                        }`}
                    >{page}</button>
                ))}
            </nav>
        </div>
      )}
    </div>
  );
}