"use client";

import { useState, useTransition, Fragment } from "react";
import { toast } from "react-hot-toast";
import { sendCustomEmail } from "../_actions/orderActions";
import { Mail, Loader2, X } from "lucide-react";
import { Dialog, Transition } from '@headlessui/react';

export default function SendEmailModal({
  customerId,
  customerName,
}: {
  customerId: string;
  customerName: string;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  const openModal = () => setIsOpen(true);
  const closeModal = () => {
    setIsOpen(false);
    // Reset fields on close
    setSubject("");
    setMessage("");
  };

  const handleSendEmail = () => {
    if (!subject || !message) {
      toast.error("Subject and message are required.");
      return;
    }
    startTransition(async () => {
      const result = await sendCustomEmail(customerId, subject, message);
      if (result.success) {
        toast.success(result.message);
        closeModal();
      } else {
        toast.error(result.message);
      }
    });
  };

  return (
    <>
      <button
        onClick={openModal}
        className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition-colors"
      >
        <Mail size={16} />
        Send Custom Email
      </button>

      <Transition appear show={isOpen} as={Fragment}>
        <Dialog as="div" className="relative z-50" onClose={closeModal}>
          <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
            <div className="fixed inset-0 bg-black/50" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0 scale-95" enterTo="opacity-100 scale-100" leave="ease-in duration-200" leaveFrom="opacity-100 scale-100" leaveTo="opacity-0 scale-95">
                <Dialog.Panel className="w-full max-w-lg transform overflow-hidden rounded-lg bg-white dark:bg-gray-800 text-left align-middle shadow-xl transition-all">
                  <div className="p-6">
                      <div className="flex justify-between items-center pb-4 border-b dark:border-gray-700">
                          <Dialog.Title as="h3" className="text-xl font-bold text-gray-900 dark:text-gray-100">
                              Send Email to {customerName}
                          </Dialog.Title>
                           <button onClick={closeModal} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"><X size={20}/></button>
                      </div>

                      <div className="mt-4 space-y-4">
                          <div>
                              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subject</label>
                              <input type="text" value={subject} onChange={(e) => setSubject(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-900 shadow-sm"/>
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
                              <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={6} className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-900 shadow-sm"/>
                          </div>
                      </div>
                  </div>
                  
                  <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end gap-4">
                    <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 font-semibold rounded-md hover:bg-gray-300 dark:hover:bg-gray-500">Cancel</button>
                    <button onClick={handleSendEmail} disabled={isPending} className="flex items-center justify-center gap-2 px-4 py-2 bg-brand-primary text-white font-semibold rounded-md hover:bg-brand-primary-hover disabled:bg-opacity-70">
                      {isPending && <Loader2 className="animate-spin" size={18}/>}
                      {isPending ? "Sending..." : "Send Email"}
                    </button>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </>
  );
}