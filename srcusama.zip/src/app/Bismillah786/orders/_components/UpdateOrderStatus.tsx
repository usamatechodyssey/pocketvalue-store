"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";
import { updateOrderStatus } from "../_actions/orderActions";
import { Loader2 } from "lucide-react";

export default function UpdateOrderStatus({
  orderId,
  currentStatus,
}: {
  orderId: string;
  currentStatus: string;
}) {
  const [newStatus, setNewStatus] = useState(currentStatus);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const handleUpdate = () => {
    startTransition(async () => {
      const result = await updateOrderStatus(orderId, newStatus);
      if (result?.success) {
        toast.success(result.message);
        router.refresh(); // Refresh server component to show new status
      } else {
        toast.error(result?.message || "Failed to update status.");
      }
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border dark:border-gray-700">
      <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-100">
        Update Order Status
      </h2>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
        Select a new status for this order. An email notification will be sent to the customer automatically.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <select
          value={newStatus}
          onChange={(e) => setNewStatus(e.target.value)}
          className="flex-grow p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-900 shadow-sm focus:ring-brand-primary focus:border-brand-primary"
        >
          <option value="Pending">Pending</option>
          <option value="Processing">Processing</option>
          <option value="Shipped">Shipped</option>
          <option value="Delivered">Delivered</option>
          <option value="Cancelled">Cancelled</option>
        </select>
        <button
          onClick={handleUpdate}
          disabled={isPending || newStatus === currentStatus}
          className="w-full sm:w-auto flex items-center justify-center gap-2 bg-brand-primary text-on-primary font-semibold px-6 py-2 rounded-md hover:bg-brand-primary-hover transition-colors disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
        >
          {isPending && <Loader2 className="animate-spin" size={18} />}
          {isPending ? "Updating..." : "Update"}
        </button>
      </div>
    </div>
  );
}