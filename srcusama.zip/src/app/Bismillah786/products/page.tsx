import Link from "next/link";
import { PlusCircle } from "lucide-react";
import { getPaginatedAdminProducts } from "./_actions/productActions";
import ProductsClientPage from "./_components/ProductsClientPage";
import { Suspense } from "react";
import { ClipLoader } from "react-spinners";

// Correctly type the props for Next.js 15+ async pages
type AdminProductsPageProps = {
  searchParams: Promise<{ 
    page?: string;
    search?: string;
  }>;
}

// Data fetching component
async function ProductList({ searchParams }: { searchParams: { page?: string; search?: string; } }) {
  const page = Number(searchParams.page) || 1;
  const searchTerm = searchParams.search || "";
  
  // Fetch initial paginated data on the server
  const { products, totalPages } = await getPaginatedAdminProducts({ 
    page, 
    searchTerm 
  });

  return (
    <ProductsClientPage 
      initialProducts={products} 
      initialTotalPages={totalPages} 
    />
  );
}

// Main page component
export default async function AdminProductsPage(props: AdminProductsPageProps) {
  const searchParams = await props.searchParams;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Manage Products</h1>
        <div className="flex items-center gap-4">
          <Link
            href="/Bismillah786/products/import"
            className="text-sm font-medium text-brand-primary hover:underline"
          >
            Import from CSV
          </Link>
          <Link
            href="/Bismillah786/products/new"
            className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-on-primary font-semibold rounded-md hover:bg-brand-primary-hover transition-colors"
          >
            <PlusCircle size={20} /> Add New Product
          </Link>
        </div>
      </div>

      <Suspense
        key={`${searchParams.page}-${searchParams.search}`}
        fallback={
          <div className="flex justify-center items-center h-96 bg-white dark:bg-gray-800 rounded-lg shadow-md border dark:border-gray-700">
            <ClipLoader color="#F97316" size={50} />
          </div>
        }
      >
        <ProductList searchParams={searchParams} />
      </Suspense>
    </div>
  );
}