"use client";

import React, { useState, useEffect, useTransition } from "react";
import Image from "next/image";
import Link from "next/link";
import { urlFor } from "@/sanity/lib/image";
import { ChevronDown, ChevronRight, Search, ChevronLeft } from "lucide-react";
import DeleteProductButton from "./DeleteProductButton";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import CopyButton from "../../_components/CopyButton";

// Type Definitions
interface Variant { _key: string; name: string; sku?: string; price?: number; inStock: boolean; stock?: number; }
interface AdminProductListItem {
  _id: string; title: string; slug: string; price?: number; stock?: number; inStock?: boolean;
  mainImage?: any; variantsCount: number; variants: Variant[]; brand?: { name: string };
}

function useDebounce(value: string, delay: number) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}
// Pagination Component
function Pagination({ totalPages, currentPage, onPageChange, isPending }: { totalPages: number; currentPage: number; onPageChange: (page: number) => void; isPending: boolean; }) {
    return (
        <nav className="flex items-center justify-center gap-4 mt-8">
            <button onClick={() => onPageChange(currentPage - 1)} disabled={currentPage <= 1 || isPending} className="flex items-center gap-1 text-sm font-semibold disabled:opacity-50">
                <ChevronLeft size={16}/> Previous
            </button>
            <span className="text-sm">Page {currentPage} of {totalPages}</span>
            <button onClick={() => onPageChange(currentPage + 1)} disabled={currentPage >= totalPages || isPending} className="flex items-center gap-1 text-sm font-semibold disabled:opacity-50">
                Next <ChevronRight size={16}/>
            </button>
        </nav>
    )
}

// Main Component
export default function ProductsClientPage({
  initialProducts,
  initialTotalPages,
}: {
  initialProducts: AdminProductListItem[];
  initialTotalPages: number;
}) {
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null);
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [isPending, startTransition] = useTransition();

  const currentPage = Number(searchParams.get('page')) || 1;
  const currentSearch = searchParams.get('search') || '';

  const [searchTerm, setSearchTerm] = useState(currentSearch);
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  // --- FINAL FIX IS HERE: SIMPLIFIED useEffect for Search ---
  useEffect(() => {
    // Sirf tab URL update karo jab user ne type karna band kar diya ho
    // aur uski value URL se mukhtalif ho.
    if (debouncedSearchTerm !== currentSearch) {
        const params = new URLSearchParams(searchParams.toString());
        params.set('page', '1');
        if (debouncedSearchTerm) {
            params.set("search", debouncedSearchTerm);
        } else {
            params.delete("search");
        }
        startTransition(() => {
            router.push(`${pathname}?${params.toString()}`);
        });
    }
  }, [debouncedSearchTerm, currentSearch, pathname, router, searchParams]);
  
  const handlePageChange = (page: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set('page', page.toString());
    startTransition(() => {
      router.push(`${pathname}?${params.toString()}`);
    });
  };

  const toggleRow = (id: string) => setExpandedRowId(expandedRowId === id ? null : id);
  const formatPrice = (price?: number) => price != null ? `Rs. ${price.toLocaleString()}` : "N/A";

  return (
    <div className={`transition-opacity ${isPending ? 'opacity-60' : 'opacity-100'}`}>
        <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-md border dark:border-gray-700">
             <div className="mb-4 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20}/>
                <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by Product Name, SKU..."
                    className="w-full p-2 pl-10 border rounded-md"
                />
            </div>

            {/* --- RESPONSIVE TABLE/CARD LAYOUT --- */}
      <div className="lg:hidden space-y-4">
          {initialProducts.length > 0 ? initialProducts.map(product => {
              // --- FINAL FIX IS HERE ---
              const isExpanded = expandedRowId === product._id;
              // --- END OF FIX ---
              
              return (
              <div key={product._id} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg border dark:border-gray-600">
                  <div className="flex gap-4">
                      <div className="relative h-16 w-16 flex-shrink-0 bg-white dark:bg-gray-800 rounded-md">
                          {product.mainImage ? <Image src={urlFor(product.mainImage).url()} alt={product.title} fill sizes="64px" className="object-contain" /> : <span className="text-xs text-gray-400">No Img</span>}
                      </div>
                      <div className="flex-grow">
                          <p className="text-sm font-bold text-gray-900 dark:text-gray-100 line-clamp-2">{product.title}</p>
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">ID: <span className="font-mono">...{product._id.slice(-8)}</span><CopyButton textToCopy={product._id} /></div>
                      </div>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                      <div><p className="text-xs text-gray-500">Price</p><p className="font-semibold">{formatPrice(product.price)}</p></div>
                      <div>
                          <p className="text-xs text-gray-500">Stock</p>
                          {product.variantsCount > 1 ? <span className="font-semibold">{product.variantsCount} Variants</span> : <span className={`font-semibold ${product.inStock ? "text-green-600" : "text-red-600"}`}>{product.inStock ? "In Stock" : "Out of Stock"}</span>}
                      </div>
                  </div>
                  <div className="mt-4 border-t dark:border-gray-600 pt-3 flex justify-between items-center">
                      <button onClick={() => toggleRow(product._id)} disabled={!product.variants} className="text-xs font-semibold text-gray-600 dark:text-gray-300 hover:underline disabled:opacity-50 flex items-center gap-1">
                          {product.variants && (isExpanded ? "Hide Variants" : "Show Variants")}
                          {product.variants && (isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />)}
                      </button>
                      <div className="flex items-center gap-4">
                          <Link href={`/Bismillah786/products/${product.slug}/edit`} className="text-sm font-medium text-brand-primary hover:underline">Edit</Link>
                          <DeleteProductButton productId={product._id} productTitle={product.title} />
                      </div>
                  </div>
                   {isExpanded && product.variants && (
                        <div className="mt-4 bg-gray-100 dark:bg-gray-800 p-3 rounded-md text-xs">
                            <h4 className="font-bold mb-2">Variants:</h4>
                            <ul>{product.variants.map(v => <li key={v._key} className="flex justify-between border-b dark:border-gray-700 py-1 last:border-b-0"><span>{v.name} (SKU: {v.sku || 'N/A'})</span><span className={v.inStock ? 'text-green-600' : 'text-red-600'}>{v.stock !== undefined ? `${v.stock} units` : (v.inStock ? 'In Stock' : 'Out')}</span></li>)}</ul>
                        </div>
                   )}
              </div>
          )}) : <p className="text-center py-16 text-gray-500">No products found for this search.</p>}
      </div>


            {/* Desktop View: Table */}
            <div className="hidden lg:block overflow-x-auto">
                <table className="w-full table-auto border-collapse text-sm">
                <thead className="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                    <th className="w-12 px-4 py-3"></th>
                    <th className="w-20 px-6 py-3 text-left font-semibold uppercase text-gray-500 dark:text-gray-400">Image</th>
                    <th className="px-6 py-3 text-left font-semibold uppercase text-gray-500 dark:text-gray-400">Product Name & ID</th>
                    <th className="w-40 px-6 py-3 text-left font-semibold uppercase text-gray-500 dark:text-gray-400">Price</th>
                    <th className="w-40 px-6 py-3 text-left font-semibold uppercase text-gray-500 dark:text-gray-400">Stock / Variants</th>
                    <th className="w-28 px-6 py-3 text-right font-semibold uppercase text-gray-500 dark:text-gray-400">Actions</th>
                    </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {initialProducts.length > 0 ? (
                    initialProducts.map((product) => {
                        const isExpanded = expandedRowId === product._id;
                        return (
                        <React.Fragment key={product._id}>
                            <tr className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="px-4 py-4 text-center"><button onClick={() => toggleRow(product._id)} disabled={!product.variants} className="p-1 disabled:opacity-25">{product.variants && (isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />)}</button></td>
                            <td className="px-6 py-4"><div className="relative h-12 w-12">{product.mainImage ? <Image src={urlFor(product.mainImage).url()} alt={product.title} fill sizes="48px" className="object-contain" /> : <span className="text-xs">No Img</span>}</div></td>
                            <td className="px-6 py-4 align-top"><div className="font-medium text-gray-900 dark:text-gray-100">{product.title}</div><div className="text-xs mt-1">ID: <span className="font-mono">...{product._id.slice(-8)}</span><CopyButton textToCopy={product._id} /></div></td>
                            <td className="px-6 py-4 align-top font-semibold">{formatPrice(product.price)}</td>
                            <td className="px-6 py-4 align-top">
                                {product.variantsCount > 1 ? (<span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">{product.variantsCount} Variants</span>) : (<span className={`px-2 py-1 text-xs rounded-full ${product.inStock ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>{product.inStock ? `${product.variants[0]?.stock || 0} in stock` : "Out of Stock"}</span>)}
                            </td>
                            <td className="px-6 py-4 align-top text-right"><div className="flex items-center justify-end space-x-4"><Link href={`/Bismillah786/products/${product.slug}/edit`} className="font-medium text-brand-primary hover:underline">Edit</Link><DeleteProductButton productId={product._id} productTitle={product.title} /></div></td>
                            </tr>
                         {isExpanded && product.variants && (
                      <tr><td colSpan={6} className="p-0"><div className="bg-gray-100 dark:bg-gray-900 p-4 m-2 md:mx-4 rounded-lg border dark:border-gray-700">
                          <h4 className="font-bold mb-2 text-sm">Variants:</h4>
                          <table className="w-full text-xs">
                            <thead className="bg-gray-200 dark:bg-gray-800"><tr><th className="p-2 text-left font-medium">Name</th><th className="p-2 text-left font-medium">SKU</th><th className="p-2 text-left font-medium">Price</th><th className="p-2 text-left font-medium">Stock</th></tr></thead>
                            <tbody>
                              {product.variants.map((variant) => (
                                <tr key={variant._key} className="border-b dark:border-gray-700 last:border-0">
                                  <td className="p-2">{variant.name}</td>
                                  <td className="p-2 font-mono">{variant.sku || "N/A"}</td>
                                  <td className="p-2">{formatPrice(variant.price)}</td>
                                  <td className="p-2"><span className={`font-semibold ${variant.inStock ? "text-green-700" : "text-red-700"}`}>{variant.stock !== undefined ? `${variant.stock} units` : (variant.inStock ? "In Stock" : "Out")}</span></td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                      </div></td></tr>
                    )}
                        </React.Fragment>
                        );
                    })
                    ) : ( <tr><td colSpan={6} className="text-center py-16 text-gray-500">No products found.</td></tr> )}
                </tbody>
                </table>
            </div>
        </div>

       {initialTotalPages > 1 && (
            <Pagination totalPages={initialTotalPages} currentPage={currentPage} onPageChange={handlePageChange} isPending={isPending}/>
        )}
    </div>
  );
}