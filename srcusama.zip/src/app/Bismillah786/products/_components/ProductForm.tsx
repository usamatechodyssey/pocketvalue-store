// // /app/admin/products/_components/ProductForm.tsx
// "use client";

// import { useState } from "react";
// import TiptapEditor from "./RichTextEditor";
// import { toast } from "react-hot-toast";
// import { createProduct, updateProduct } from "../_actions/productActions";
// import { useRouter } from "next/navigation";
// import { PlusCircle, Trash2 } from "lucide-react";
// import ImageUploader from "./ImageUploader"; // NAYA: ImageUploader import karein

// // --- Type Definitions ---
// interface SanityAsset {
//   _type: "reference";
//   _ref: string;
// }
// interface Category {
//   _id: string;
//   name: string;
// }
// interface Attribute {
//   id: number;
//   name: string;
//   values: string[];
// }
// interface Variant {
//   _key: string;
//   name: string;
//   sku: string;
//   price: number;
//   inStock: boolean;
//   attributes: { name: string; value: string }[];
// }
// interface ProductData {
//   _id?: string;
//   title?: string;
//   slug?: string;
//   description?: any;
//   price?: number;
//   salePrice?: number;
//   brand?: string;
//   inStock?: boolean;
//   isBestSeller?: boolean;
//   isNewArrival?: boolean;
//   isFeatured?: boolean;
//   categories?: string[];
//   variants?: Variant[];
//   images?: SanityAsset[];
// }
// interface ProductFormProps {
//   categories: Category[];
//   initialData?: ProductData;
// }

// // === The Main Component ===
// export default function ProductForm({
//   categories,
//   initialData,
// }: ProductFormProps) {
//   const isEditMode = !!initialData?._id;
//   const router = useRouter();

//   // === State Hooks ===
//   const [productType, setProductType] = useState<"simple" | "variable">(
//     initialData?.variants && initialData.variants.length > 0
//       ? "variable"
//       : "simple"
//   );
//   const [description, setDescription] = useState(
//     initialData?.description || null
//   );
//   const [selectedCategories, setSelectedCategories] = useState<string[]>(
//     initialData?.categories || []
//   );
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [attributes, setAttributes] = useState<Attribute[]>([
//     { id: Date.now(), name: "", values: [] },
//   ]);
//   const [variants, setVariants] = useState<Variant[]>(
//     initialData?.variants || []
//   );
//   const [uploadedImages, setUploadedImages] = useState<SanityAsset[]>(
//     initialData?.images || []
//   );

//   // --- All Handler Functions ---
//   const handleAddAttribute = () =>
//     setAttributes([...attributes, { id: Date.now(), name: "", values: [] }]);
//   const handleRemoveAttribute = (id: number) =>
//     setAttributes(attributes.filter((attr) => attr.id !== id));
//   const handleAttributeNameChange = (id: number, newName: string) =>
//     setAttributes(
//       attributes.map((attr) =>
//         attr.id === id ? { ...attr, name: newName } : attr
//       )
//     );
//   const handleAttributeValueChange = (id: number, newValues: string[]) =>
//     setAttributes(
//       attributes.map((attr) =>
//         attr.id === id ? { ...attr, values: newValues } : attr
//       )
//     );
//   const handleGenerateVariants = () => {
//     const validAttributes = attributes.filter(
//       (attr) => attr.name && attr.values.length > 0
//     );
//     if (validAttributes.length === 0) {
//       toast.error("Please define at least one attribute with values.");
//       return;
//     }
//     const combinations = validAttributes.reduce(
//       (acc, attr) =>
//         acc.flatMap((d) =>
//           attr.values.map((v) => [...d, { name: attr.name, value: v }])
//         ),
//       [[]] as { name: string; value: string }[][]
//     );
//     const newVariants: Variant[] = combinations.map((combo) => {
//       const name = combo.map((c) => c.value).join(" / ");
//       const existingVariant = variants.find((v) => v.name === name);
//       return {
//         _key: existingVariant?._key || `v_${Date.now()}_${Math.random()}`,
//         name,
//         sku: existingVariant?.sku || "",
//         price: existingVariant?.price || 0,
//         inStock: existingVariant?.inStock ?? true,
//         attributes: combo,
//       };
//     });
//     setVariants(newVariants);
//     toast.success(`${newVariants.length} variants generated!`);
//   };
//   const handleVariantChange = (key: string, field: keyof Variant, value: any) =>
//     setVariants(
//       variants.map((v) => (v._key === key ? { ...v, [field]: value } : v))
//     );
//   const handleCategoryChange = (categoryId: string) => {
//     if (typeof categoryId !== "string" || !categoryId) return;
//     setSelectedCategories((prev) => {
//       const newSelection = prev.includes(categoryId)
//         ? prev.filter((id) => id !== categoryId)
//         : [...prev, categoryId];
//       return newSelection.filter((id) => id);
//     });
//   };

//   // --- FINAL SUBMIT HANDLER ---
//   const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
//     e.preventDefault();
//     if (uploadedImages.length === 0) {
//       toast.error("Please upload at least one product image.");
//       return;
//     }
//     if (selectedCategories.length === 0) {
//       toast.error("Please select at least one category.");
//       return;
//     }
//     if (productType === "variable" && variants.length === 0) {
//       toast.error("Please generate variants for a variable product.");
//       return;
//     }

//     setIsSubmitting(true);
//     toast.loading(isEditMode ? "Updating product..." : "Saving product...");

//     const formData = new FormData(e.currentTarget);

//     const commonData = {
//       title: formData.get("title"),
//       slug: formData.get("slug"),
//       brand: formData.get("brand"),
//       description: description,
//       categories: selectedCategories,
//       isBestSeller: formData.get("isBestSeller") === "on",
//       isNewArrival: formData.get("isNewArrival") === "on",
//       isFeatured: formData.get("isFeatured") === "on",
//       productType: productType,
//       images: uploadedImages.map((img) => ({
//         _type: "image",
//         asset: { _type: "reference", _ref: img._ref },
//       })),
//     };

//     let finalData;
//     if (productType === "simple") {
//       finalData = {
//         ...commonData,
//         price: Number(formData.get("price")),
//         salePrice: Number(formData.get("salePrice")) || 0,
//         inStock: formData.get("inStock") === "on",
//         variants: [],
//       };
//     } else {
//       finalData = {
//         ...commonData,
//         price: 0,
//         salePrice: 0,
//         inStock: variants.some((v) => v.inStock),
//         variants: variants,
//       };
//     }

//     try {
//       let result;
//       if (isEditMode) {
//         result = await updateProduct(initialData!._id!, finalData);
//       } else {
//         result = await createProduct(finalData);
//       }

//       toast.dismiss();
//       if (result?.success) {
//         toast.success(result.message);
//         router.push("/Bismillah786/products");
//       } else {
//         toast.error(result?.message || "An unknown error occurred.");
//       }
//     } catch (error) {
//       toast.dismiss();
//       toast.error("An unexpected client-side error occurred.");
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   return (
//     <form
//       onSubmit={handleSubmit}
//       className="p-8 bg-white rounded-lg shadow-md border space-y-8"
//     >
//       {/* Section 1: Basic Info */}
//       <div className="space-y-6">
//         <div>
//           <label
//             htmlFor="title"
//             className="block text-sm font-medium text-gray-700 mb-1"
//           >
//             Product Title
//           </label>
//           <input
//             type="text"
//             id="title"
//             name="title"
//             defaultValue={initialData?.title}
//             className="w-full p-2 border border-gray-300 rounded-md"
//             required
//           />
//         </div>
//         <div>
//           <label
//             htmlFor="slug"
//             className="block text-sm font-medium text-gray-700 mb-1"
//           >
//             Slug
//           </label>
//           <input
//             type="text"
//             id="slug"
//             name="slug"
//             defaultValue={initialData?.slug}
//             className="w-full p-2 border border-gray-300 rounded-md"
//             required
//           />
//         </div>
//       </div>

//       {/* Section 2: Product Images Uploader */}
//       <div className="border-t pt-8">
//         <label className="block text-sm font-medium text-gray-700 mb-2">
//           Product Images
//         </label>
//         <ImageUploader
//           uploadedImages={uploadedImages}
//           setUploadedImages={setUploadedImages}
//         />
//       </div>

//       {/* Section 3: Description */}
//       <div className="border-t pt-8">
//         <label className="block text-sm font-medium text-gray-700 mb-2">
//           Description
//         </label>
//         <TiptapEditor value={description} onChange={setDescription} />
//       </div>

//       {/* Section 4: Product Type Selector */}
//       <div className="border-t pt-8">
//         <label className="block text-sm font-medium text-gray-700 mb-2">
//           Product Type
//         </label>
//         <div className="flex space-x-4">
//           <label className="flex items-center space-x-2 cursor-pointer">
//             <input
//               type="radio"
//               name="productType"
//               value="simple"
//               checked={productType === "simple"}
//               onChange={() => setProductType("simple")}
//               className="h-4 w-4 text-teal-600"
//             />
//             <span>Simple Product</span>
//           </label>
//           <label className="flex items-center space-x-2 cursor-pointer">
//             <input
//               type="radio"
//               name="productType"
//               value="variable"
//               checked={productType === "variable"}
//               onChange={() => setProductType("variable")}
//               className="h-4 w-4 text-teal-600"
//             />
//             <span>Variable Product</span>
//           </label>
//         </div>
//       </div>

//       {/* Section 5: Conditional UI (Pricing or Variants) */}
//       {productType === "simple" ? (
//         <div className="border-t pt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//           <div>
//             <label
//               htmlFor="price"
//               className="block text-sm font-medium text-gray-700 mb-1"
//             >
//               Price (Rs.)
//             </label>
//             <input
//               type="number"
//               id="price"
//               name="price"
//               defaultValue={initialData?.price}
//               className="w-full p-2 border border-gray-300 rounded-md"
//               required
//               step="0.01"
//             />
//           </div>
//           <div>
//             <label
//               htmlFor="salePrice"
//               className="block text-sm font-medium text-gray-700 mb-1"
//             >
//               Sale Price (Rs.)
//             </label>
//             <input
//               type="number"
//               id="salePrice"
//               name="salePrice"
//               defaultValue={initialData?.salePrice}
//               className="w-full p-2 border border-gray-300 rounded-md"
//               step="0.01"
//             />
//           </div>
//           <div>
//             <label
//               htmlFor="brand"
//               className="block text-sm font-medium text-gray-700 mb-1"
//             >
//               Brand
//             </label>
//             <input
//               type="text"
//               id="brand"
//               name="brand"
//               defaultValue={initialData?.brand}
//               className="w-full p-2 border border-gray-300 rounded-md"
//             />
//           </div>
//         </div>
//       ) : (
//         <div className="border-t pt-8 space-y-6">
//           <div>
//             <h3 className="text-lg font-medium text-gray-900 mb-2">
//               Product Attributes
//             </h3>
//             <p className="text-sm text-gray-500">
//               Define attributes like Color, Size, etc. Press Enter to add a
//               value.
//             </p>
//           </div>
//           <div className="space-y-4">
//             {attributes.map((attr) => (
//               <div
//                 key={attr.id}
//                 className="p-4 border rounded-md bg-gray-50 flex items-start gap-4"
//               >
//                 <div className="flex-grow grid grid-cols-1 md:grid-cols-3 gap-4">
//                   <div className="md:col-span-1">
//                     <label className="block text-sm font-medium text-gray-700">
//                       Attribute Name
//                     </label>
//                     <input
//                       type="text"
//                       placeholder="e.g., Color"
//                       value={attr.name}
//                       onChange={(e) =>
//                         handleAttributeNameChange(attr.id, e.target.value)
//                       }
//                       className="mt-1 w-full p-2 border rounded-md"
//                     />
//                   </div>
//                   <div className="md:col-span-2">
//                     <label className="block text-sm font-medium text-gray-700">
//                       Values
//                     </label>
//                     <div className="mt-1 flex flex-wrap gap-2 p-2 border rounded-md bg-white min-h-[42px]">
//                       {attr.values.map((val) => (
//                         <span
//                           key={val}
//                           className="flex items-center gap-1 bg-teal-100 text-teal-800 text-sm px-2 py-1 rounded-full"
//                         >
//                           {val}
//                           <button
//                             type="button"
//                             onClick={() =>
//                               handleAttributeValueChange(
//                                 attr.id,
//                                 attr.values.filter((v) => v !== val)
//                               )
//                             }
//                             className="text-teal-600 hover:text-teal-900"
//                           >
//                             ×
//                           </button>
//                         </span>
//                       ))}
//                       <input
//                         type="text"
//                         onKeyDown={(e) => {
//                           if (e.key === "Enter" && e.currentTarget.value) {
//                             e.preventDefault();
//                             handleAttributeValueChange(attr.id, [
//                               ...attr.values,
//                               e.currentTarget.value,
//                             ]);
//                             e.currentTarget.value = "";
//                           }
//                         }}
//                         className="flex-grow outline-none bg-transparent"
//                         placeholder="Add value and press Enter"
//                       />
//                     </div>
//                   </div>
//                 </div>
//                 <button
//                   type="button"
//                   onClick={() => handleRemoveAttribute(attr.id)}
//                   className="mt-7 p-2 text-gray-400 hover:text-red-600"
//                 >
//                   <Trash2 size={20} />
//                 </button>
//               </div>
//             ))}
//           </div>
//           <button
//             type="button"
//             onClick={handleAddAttribute}
//             className="flex items-center gap-2 text-sm font-medium text-teal-600 hover:text-teal-800"
//           >
//             <PlusCircle size={16} />
//             Add another attribute
//           </button>
//           <div className="border-t pt-6">
//             <h3 className="text-lg font-medium text-gray-900 mb-4">
//               Generated Variants
//             </h3>
//             {variants.length === 0 ? (
//               <div className="p-6 bg-gray-50 rounded-lg border text-center">
//                 <button
//                   type="button"
//                   onClick={handleGenerateVariants}
//                   className="px-5 py-2 bg-gray-600 text-white font-semibold rounded-md hover:bg-gray-700"
//                 >
//                   Generate Variants
//                 </button>
//                 <p className="text-xs text-gray-500 mt-2">
//                   (Click after defining all attributes)
//                 </p>
//               </div>
//             ) : (
//               <div className="space-y-4">
//                 <div className="overflow-x-auto">
//                   <table className="w-full text-sm">
//                     <thead className="bg-gray-100">
//                       <tr>
//                         <th className="p-2 text-left font-medium">Variant</th>
//                         <th className="p-2 text-left font-medium">Price</th>
//                         <th className="p-2 text-left font-medium">SKU</th>
//                         <th className="p-2 text-left font-medium">Stock</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {variants.map((variant) => (
//                         <tr key={variant._key} className="border-b">
//                           <td className="p-2 font-semibold text-gray-700">
//                             {variant.name}
//                           </td>
//                           <td className="p-2">
//                             <input
//                               type="number"
//                               value={variant.price}
//                               onChange={(e) =>
//                                 handleVariantChange(
//                                   variant._key,
//                                   "price",
//                                   Number(e.target.value)
//                                 )
//                               }
//                               className="w-24 p-1 border rounded-md"
//                             />
//                           </td>
//                           <td className="p-2">
//                             <input
//                               type="text"
//                               value={variant.sku}
//                               onChange={(e) =>
//                                 handleVariantChange(
//                                   variant._key,
//                                   "sku",
//                                   e.target.value
//                                 )
//                               }
//                               className="w-32 p-1 border rounded-md"
//                             />
//                           </td>
//                           <td className="p-2">
//                             <input
//                               type="checkbox"
//                               checked={variant.inStock}
//                               onChange={(e) =>
//                                 handleVariantChange(
//                                   variant._key,
//                                   "inStock",
//                                   e.target.checked
//                                 )
//                               }
//                               className="h-4 w-4 text-teal-600 rounded"
//                             />
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </table>
//                 </div>
//                 <button
//                   type="button"
//                   onClick={handleGenerateVariants}
//                   className="text-sm font-medium text-teal-600 hover:text-teal-800"
//                 >
//                   Re-generate Variants
//                 </button>
//               </div>
//             )}
//           </div>
//         </div>
//       )}

//       {/* Section 6: Categories */}
//       <div className="border-t pt-8">
//         <label className="block text-sm font-medium text-gray-700 mb-2">
//           Categories
//         </label>
//         <div className="p-4 border rounded-md max-h-60 overflow-y-auto">
//           <ul className="space-y-2">
//             {categories.map((category) => (
//               <li key={category._id}>
//                 <label className="flex items-center space-x-3 cursor-pointer">
//                   <input
//                     type="checkbox"
//                     className="h-4 w-4 text-teal-600 border-gray-300 rounded"
//                     checked={selectedCategories.includes(category._id)}
//                     onChange={() => handleCategoryChange(category._id)}
//                   />
//                   <span className="text-sm text-gray-800">{category.name}</span>
//                 </label>
//               </li>
//             ))}
//           </ul>
//         </div>
//       </div>

//       {/* Section 7: Toggles */}
//       <div className="border-t pt-8 grid grid-cols-2 md:grid-cols-4 gap-6">
//         <label className="flex items-center space-x-3 cursor-pointer">
//           <input
//             type="checkbox"
//             name="inStock"
//             defaultChecked={initialData?.inStock ?? true}
//             className="h-4 w-4 text-teal-600 rounded"
//           />
//           <span>In Stock</span>
//         </label>
//         <label className="flex items-center space-x-3 cursor-pointer">
//           <input
//             type="checkbox"
//             name="isBestSeller"
//             defaultChecked={initialData?.isBestSeller}
//             className="h-4 w-4 text-teal-600 rounded"
//           />
//           <span>Best Seller</span>
//         </label>
//         <label className="flex items-center space-x-3 cursor-pointer">
//           <input
//             type="checkbox"
//             name="isNewArrival"
//             defaultChecked={initialData?.isNewArrival}
//             className="h-4 w-4 text-teal-600 rounded"
//           />
//           <span>New Arrival</span>
//         </label>
//         <label className="flex items-center space-x-3 cursor-pointer">
//           <input
//             type="checkbox"
//             name="isFeatured"
//             defaultChecked={initialData?.isFeatured}
//             className="h-4 w-4 text-teal-600 rounded"
//           />
//           <span>Featured</span>
//         </label>
//       </div>

//       {/* Section 8: Submit Button */}
//       <div className="flex justify-end pt-8 border-t">
//         <button
//           type="submit"
//           disabled={isSubmitting}
//           className="px-8 py-3 bg-teal-600 text-white font-semibold rounded-md hover:bg-teal-700 disabled:bg-gray-400"
//         >
//           {isSubmitting
//             ? "Saving..."
//             : isEditMode
//               ? "Update Product"
//               : "Save Product"}
//         </button>
//       </div>
//     </form>
//   );
// }
"use client";

import { useState, useTransition, Fragment } from "react";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";
import { createProduct, updateProduct } from "../_actions/productActions";
import { SanityCategory, SanityBrand } from "@/sanity/types/product_types";
import { Loader2, PlusCircle, Trash2, X } from "lucide-react";
import TiptapEditor from "./RichTextEditor";
import { Tab } from "@headlessui/react";
import Image from "next/image";
import { urlFor } from "@/sanity/lib/image";
import slugify from "slugify";
import { useDropzone } from "react-dropzone";
import { writeClient } from "@/sanity/lib/writeClient";

// --- Type Definitions ---
interface ImageAsset {
  _key: string;
  _type: "image";
  asset: { _type: "reference"; _ref: string };
}
export interface ProductVariant {
  _key: string;
  name: string;
  sku: string;
  price?: number;
  salePrice?: number;
  stock?: number;
  inStock: boolean;
  weight?: number;
  dimensions?: {
    _type?: "dimensions";
    height?: number;
    width?: number;
    depth?: number;
  };
  images: ImageAsset[];
  attributes: { _key: string; name: string; value: string }[];
}
interface ProductData {
  _id?: string;
  title?: string;
  slug?: { current: string };
  description?: any;
  videoUrl?: string;
  brandId?: string;
  categoryIds?: string[];
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isFeatured?: boolean;
  isOnDeal?: boolean;
  rating?: number;
  variants?: ProductVariant[];
}
interface ProductFormProps {
  categories: SanityCategory[];
  brands: SanityBrand[];
  initialData?: ProductData;
}

// --- Small, Reusable Variant Image Uploader ---
const VariantImageUploader = ({
  images,
  onImageUpload,
  onImageRemove,
}: {
  images: ImageAsset[];
  onImageUpload: (files: File[]) => void;
  onImageRemove: (ref: string) => void;
}) => {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: onImageUpload,
    accept: { "image/*": [] },
  });

  return (
    <div>
      <div
        {...getRootProps()}
        className={`mt-1 flex justify-center rounded-lg border border-dashed ${isDragActive ? "border-brand-primary" : "border-gray-300 dark:border-gray-600"} px-6 py-4 transition-colors`}
      >
        <div className="text-center">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Drop, paste, or click to upload
          </p>
        </div>
        <input {...getInputProps()} className="sr-only" />
      </div>
      {images.length > 0 && (
        <div className="mt-4 grid grid-cols-3 sm:grid-cols-4 gap-4">
          {images.map((image) => (
            <div key={image.asset._ref} className="relative aspect-square">
              <Image
                src={urlFor(image).width(200).height(200).url()}
                alt="Variant"
                fill
                sizes="100px"
                className="rounded-md object-cover"
              />
              <button
                type="button"
                onClick={() => onImageRemove(image.asset._ref)}
                className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 shadow-md"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// === The Main Component ===
export default function ProductForm({
  categories,
  brands,
  initialData,
}: ProductFormProps) {
  const isEditMode = !!initialData?._id;
  const router = useRouter();

  const [isSubmitting, startTransition] = useTransition();
  const [formData, setFormData] = useState({
    title: initialData?.title || "",
    slug: initialData?.slug?.current || "",
    videoUrl: initialData?.videoUrl || "",
    description: initialData?.description || null,
    brandId: initialData?.brandId || "",
    categoryIds: initialData?.categoryIds || [],
    isBestSeller: initialData?.isBestSeller || false,
    isNewArrival: initialData?.isNewArrival || false,
    isFeatured: initialData?.isFeatured || false,
    isOnDeal: initialData?.isOnDeal || false,
    rating: initialData?.rating || undefined,
  });

  const createNewVariant = (): ProductVariant => ({
    _key: `v_${Date.now()}_${Math.random()}`,
    name: "Standard",
    sku: "",
    inStock: true,
    stock: 10,
    images: [],
    attributes: [],
  });
  const [variants, setVariants] = useState<ProductVariant[]>(
    initialData?.variants?.length ? initialData.variants : [createNewVariant()]
  );

  const handleFormInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const checked = (e.target as HTMLInputElement).checked;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = e.target.value;
    setFormData((prev) => ({
      ...prev,
      title: newTitle,
      slug: slugify(newTitle, { lower: true, strict: true }),
    }));
  };

  const handleCategoryChange = (catId: string) => {
    setFormData((prev) => ({
      ...prev,
      categoryIds: prev.categoryIds.includes(catId)
        ? prev.categoryIds.filter((id) => id !== catId)
        : [...prev.categoryIds, catId],
    }));
  };

  const handleAddVariant = () =>
    setVariants((prev) => [
      ...prev,
      { ...createNewVariant(), name: `Variant ${prev.length + 1}` },
    ]);
  const handleRemoveVariant = (key: string) => {
    if (variants.length <= 1)
      return toast.error("A product must have at least one variant.");
    setVariants(variants.filter((v) => v._key !== key));
  };

  const handleVariantChange = (key: string, field: string, value: any) => {
    setVariants((prevVariants) =>
      prevVariants.map((v) => {
        if (v._key !== key) return v;

        let newVariant = { ...v, [field]: value };

        // ✅ Generate SKU safely
        if (field === "name" && formData.title) {
          const titleSlug = slugify(formData.title, {
            lower: true,
            replacement: "",
          }).slice(0, 10);
          const nameSlug = slugify(value, { lower: true, replacement: "" });
          newVariant.sku = `${titleSlug.toUpperCase()}-${nameSlug.toUpperCase()}`;
        }

        // ✅ Manage stock
        if (field === "stock") {
          newVariant.inStock = value > 0;
        }

        // ✅ Manage nested dimensions
        if (field.startsWith("dimensions.")) {
          const dimKey = field.split(
            "."
          )[1] as keyof ProductVariant["dimensions"];
          newVariant.dimensions = {
            ...newVariant.dimensions,
            _type: "dimensions",
            [dimKey]: value,
          };
        }

        return newVariant;
      })
    );
  };

  const handleVariantImageUpload = async (key: string, files: File[]) => {
    toast.loading("Uploading images...");
    const uploadPromises = files.map((file) =>
      writeClient.assets.upload("image", file)
    );
    try {
      const assets = await Promise.all(uploadPromises);
      const newImages = assets.map((asset) => ({
        _key: `img_${Date.now()}_${Math.random()}`,
        _type: "image" as const,
        asset: { _type: "reference" as const, _ref: asset._id },
      }));
      setVariants((prev) =>
        prev.map((v) =>
          v._key === key ? { ...v, images: [...v.images, ...newImages] } : v
        )
      );
      toast.dismiss();
      toast.success("Images uploaded!");
    } catch (error) {
      toast.dismiss();
      toast.error("Image upload failed.");
    }
  };

  const handleRemoveVariantImage = (key: string, ref: string) => {
    setVariants((prev) =>
      prev.map((v) =>
        v._key === key
          ? { ...v, images: v.images.filter((img) => img.asset._ref !== ref) }
          : v
      )
    );
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!formData.title) return toast.error("Product title is required.");
    startTransition(async () => {
      const result = isEditMode
        ? await updateProduct(initialData!._id!, { ...formData, variants })
        : await createProduct({ ...formData, variants });
      if (result.success) {
        toast.success(result.message);
        router.push("/Bismillah786/products");
      } else {
        toast.error(result.message);
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <Tab.Group>
        <Tab.List className="flex space-x-1 rounded-xl bg-gray-200 dark:bg-gray-700 p-1">
          {["Details", "Variants", "Marketing & Organization"].map(
            (category) => (
              <Tab key={category} as={Fragment}>
                {({ selected }) => (
                  <button
                    className={`w-full rounded-lg py-2.5 text-sm font-medium leading-5 transition-colors focus:outline-none ${
                      selected
                        ? "bg-white dark:bg-gray-800 shadow text-brand-primary"
                        : "text-gray-600 dark:text-gray-400 hover:bg-white/[0.5] dark:hover:bg-gray-800/[0.5]"
                    }`}
                  >
                    {category}
                  </button>
                )}
              </Tab>
            )
          )}
        </Tab.List>
        <Tab.Panels className="mt-4">
          <Tab.Panel className="space-y-6 p-4 bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700">
            <div>
              <label className="block text-sm font-medium">Product Title</label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleTitleChange}
                required
                className="mt-1 block w-full rounded-md shadow-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium">Slug</label>
              <input
                type="text"
                name="slug"
                value={formData.slug}
                onChange={handleFormInputChange}
                required
                className="mt-1 block w-full rounded-md shadow-sm bg-gray-50 dark:bg-gray-700"
                readOnly
              />
            </div>
            <div>
              <label className="block text-sm font-medium">Description</label>
              <TiptapEditor
                value={formData.description}
                onChange={(newDesc) =>
                  setFormData((p) => ({ ...p, description: newDesc }))
                }
              />
            </div>
            <div>
              <label className="block text-sm font-medium">
                Video URL (Optional)
              </label>
              <input
                type="url"
                name="videoUrl"
                value={formData.videoUrl}
                onChange={handleFormInputChange}
                className="mt-1 block w-full rounded-md shadow-sm"
              />
            </div>
          </Tab.Panel>

          <Tab.Panel className="space-y-6 p-4 bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700">
            <div className="space-y-6">
              {variants.map((variant, index) => (
                <div
                  key={variant._key}
                  className="p-4 border dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700/50 relative"
                >
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-gray-800 dark:text-gray-200">
                      Variant #{index + 1}
                    </h3>
                    <button
                      type="button"
                      onClick={() => handleRemoveVariant(variant._key)}
                      className="p-1 text-gray-400 hover:text-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs">Name</label>
                      <input
                        type="text"
                        value={variant.name}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "name",
                            e.target.value
                          )
                        }
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs">SKU</label>
                      <input
                        type="text"
                        value={variant.sku}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "sku",
                            e.target.value
                          )
                        }
                      />
                    </div>
                    <div>
                      <label className="text-xs">Price (PKR)</label>
                      <input
                        type="number"
                        value={variant.price}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "price",
                            Number(e.target.value)
                          )
                        }
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs">Sale Price</label>
                      <input
                        type="number"
                        value={variant.salePrice}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "salePrice",
                            Number(e.target.value)
                          )
                        }
                      />
                    </div>
                    <div>
                      <label className="text-xs">Stock Qty</label>
                      <input
                        type="number"
                        value={variant.stock}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "stock",
                            parseInt(e.target.value) || 0
                          )
                        }
                      />
                    </div>
                    <div>
                      <label className="text-xs">Weight (kg)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={variant.weight}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "weight",
                            Number(e.target.value)
                          )
                        }
                      />
                    </div>
                  </div>
                  <div className="mt-4">
                    <label className="text-xs">Dimensions (cm)</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        placeholder="H"
                        value={variant.dimensions?.height}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "dimensions.height",
                            Number(e.target.value)
                          )
                        }
                      />
                      <input
                        type="number"
                        placeholder="W"
                        value={variant.dimensions?.width}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "dimensions.width",
                            Number(e.target.value)
                          )
                        }
                      />
                      <input
                        type="number"
                        placeholder="D"
                        value={variant.dimensions?.depth}
                        onChange={(e) =>
                          handleVariantChange(
                            variant._key,
                            "dimensions.depth",
                            Number(e.target.value)
                          )
                        }
                      />
                    </div>
                  </div>
                  <div className="mt-4">
                    <label className="text-xs">Images</label>
                    <VariantImageUploader
                      images={variant.images}
                      onImageUpload={(files) =>
                        handleVariantImageUpload(variant._key, files)
                      }
                      onImageRemove={(ref) =>
                        handleRemoveVariantImage(variant._key, ref)
                      }
                    />
                  </div>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={handleAddVariant}
              className="mt-4 flex items-center gap-2 text-sm font-medium text-brand-primary hover:underline"
            >
              <PlusCircle size={16} /> Add Another Variant
            </button>
          </Tab.Panel>

          <Tab.Panel className="space-y-6 p-4 bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium">Brand</label>
                <select
                  name="brandId"
                  value={formData.brandId}
                  onChange={handleFormInputChange}
                  className="mt-1 block w-full rounded-md shadow-sm"
                >
                  <option value="">Select a brand</option>
                  {brands.map((b) => (
                    <option key={b._id} value={b._id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium">
                  Initial Rating (1-5)
                </label>
                <input
                  type="number"
                  name="rating"
                  value={formData.rating}
                  onChange={handleFormInputChange}
                  min="1"
                  max="5"
                  step="0.1"
                  className="mt-1 block w-full rounded-md shadow-sm"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium">Categories</label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4 border rounded-md max-h-60 overflow-y-auto mt-1">
                {categories.map((c) => (
                  <label
                    key={c._id}
                    className="flex items-center gap-2 text-sm"
                  >
                    <input
                      type="checkbox"
                      checked={formData.categoryIds.includes(c._id)}
                      onChange={() => handleCategoryChange(c._id)}
                    />
                    {c.name}
                  </label>
                ))}
              </div>
            </div>
            <div className="flex flex-wrap gap-x-6 gap-y-4 pt-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="isBestSeller"
                  checked={formData.isBestSeller}
                  onChange={handleFormInputChange}
                />{" "}
                Best Seller
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="isNewArrival"
                  checked={formData.isNewArrival}
                  onChange={handleFormInputChange}
                />{" "}
                New Arrival
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="isFeatured"
                  checked={formData.isFeatured}
                  onChange={handleFormInputChange}
                />{" "}
                Featured
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="isOnDeal"
                  checked={formData.isOnDeal}
                  onChange={handleFormInputChange}
                />{" "}
                On Deal
              </label>
            </div>
          </Tab.Panel>
        </Tab.Panels>
      </Tab.Group>

      <div className="flex justify-end pt-8 border-t dark:border-gray-700">
        <button
          type="submit"
          disabled={isSubmitting}
          className="flex items-center justify-center gap-2 px-8 py-3 bg-brand-primary text-white font-semibold rounded-md hover:bg-brand-primary-hover disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {isSubmitting && <Loader2 className="animate-spin" size={20} />}
          {isSubmitting
            ? "Saving..."
            : isEditMode
              ? "Update Product"
              : "Save Product"}
        </button>
      </div>
      <style jsx global>{`
        label {
          color: var(--color-text-secondary);
        }
        input[type="text"],
        input[type="url"],
        input[type="number"],
        select,
        textarea {
          background-color: var(--color-surface-base);
          border: 1px solid var(--color-surface-border-darker);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          width: 100%;
        }
      `}</style>
    </form>
  );
}
