import ProductForm from "../_components/ProductForm";
import { getFormData } from "../_actions/productActions";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default async function NewProductPage() {
  // Fetch both categories and brands in a single call
  const { categories, brands } = await getFormData();

  return (
    <div className="space-y-6">
       <div className="flex items-center gap-4">
            <Link href="/Bismillah786/products" className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                <ArrowLeft size={20} />
            </Link>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">
                Add a New Product
            </h1>
       </div>
      
      <ProductForm 
        categories={categories || []} 
        brands={brands || []}
      />
    </div>
  );
}