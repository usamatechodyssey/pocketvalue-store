import { notFound } from "next/navigation";
import ProductForm from "../../_components/ProductForm";
import { getFormData, getSingleProductForEdit } from "../../_actions/productActions";
import { portableTextToTiptapJson } from "@/utils/portableTextToTiptap"; // Make sure this path is correct
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

// Correctly type the props for Next.js 15+ async pages
type EditProductPageProps = {
  params: Promise<{ slug: string }>;
}

export default async function EditProductPage(props: EditProductPageProps) {
  // Correctly await the params
  const params = await props.params;
  
  // Fetch product data and form data (categories/brands) in parallel for efficiency
  const [product, formData] = await Promise.all([
    getSingleProductForEdit(params.slug),
    getFormData(),
  ]);

  if (!product) {
    notFound();
  }

  // Convert Sanity's Portable Text to Tiptap's JSON format
  const tiptapDescription = portableTextToTiptapJson(product.description);
  
  // Prepare the initial data object for the form, matching the new schema
  const initialData = {
    ...product,
    slug: product.slug, // Pass the whole slug object
    description: tiptapDescription,
    categoryIds: product.categoryIds || [],
    brandId: product.brandId || '',
    variants: product.variants || [],
  };

  return (
    <div className="space-y-6">
       <div className="flex items-center gap-4">
            <Link href="/Bismillah786/products" className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                <ArrowLeft size={20} />
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">
                  Edit Product
              </h1>
              <p className="text-sm text-gray-500 truncate max-w-sm">Editing: {product.title}</p>
            </div>
       </div>
      
      <ProductForm
        categories={formData.categories || []}
        brands={formData.brands || []}
        initialData={initialData}
      />
    </div>
  );
}