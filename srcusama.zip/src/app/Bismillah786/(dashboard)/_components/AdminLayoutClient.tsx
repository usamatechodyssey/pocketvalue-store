"use client";

import { useState, Fragment } from "react";
import AdminSidebar from "../../_components/AdminSidebar";
import { Menu } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

export default function AdminLayoutClient({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-gray-100 dark:bg-gray-900">
      {/* Mobile Sidebar (Off-canvas) - No Changes */}
      <AnimatePresence>
        {isSidebarOpen && (
           <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }} onClick={() => setIsSidebarOpen(false)} className="fixed inset-0 bg-black/50 z-40 lg:hidden" aria-hidden="true"/>
              <motion.div initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }} transition={{ type: "spring", stiffness: 300, damping: 30 }} className="fixed top-0 left-0 h-full z-50 lg:hidden">
                 <AdminSidebar />
              </motion.div>
           </>
        )}
      </AnimatePresence>

      {/* --- FINAL FIX IS HERE: DESKTOP SIDEBAR --- */}
      {/* Hum is per `h-screen` aur `sticky` classes lagayenge taake yeh apni jaga per fix rahe */}
      <div className="hidden lg:block h-screen sticky top-0 flex-shrink-0">
        <AdminSidebar />
      </div>

      {/* Main Content Area - No Changes */}
      <div className="flex-1 flex flex-col w-full min-w-0">
        <header className="lg:hidden sticky top-0 bg-white dark:bg-gray-800 p-4 border-b dark:border-gray-700 shadow-sm z-30 flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(true)} aria-label="Open sidebar" className="text-gray-800 dark:text-gray-200">
                <Menu />
            </button>
            <h1 className="text-lg font-bold text-gray-800 dark:text-gray-200">Admin Panel</h1>
        </header>

        <main className="flex-1 p-4 sm:p-6 md:p-8">
            {children}
        </main>
      </div>
    </div>
  );
}