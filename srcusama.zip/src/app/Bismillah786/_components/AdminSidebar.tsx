"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { LayoutDashboard, ShoppingCart, Package, Users, LogOut, BarChart, FileUp, ListOrdered } from "lucide-react";
import { toast } from "react-hot-toast";

const navItems = [
  { href: "/Bismillah786", label: "Dashboard", icon: LayoutDashboard },
  { href: "/Bismillah786/orders", label: "Orders", icon: ShoppingCart },
  { href: "/Bismillah786/products", label: "Products", icon: Package },
  { href: "/Bismillah786/categories", label: "Categories", icon: ListOrdered },
  { href: "/Bismillah786/users", label: "Customers", icon: Users },
  { href: "/Bismillah786/analytics", label: "Analytics", icon: BarChart },
];

const secondaryNavItems = [
    { href: "/Bismillah786/products/import", label: "Import Products", icon: FileUp },
    { href: "/Bismillah786/categories/import", label: "Import Categories", icon: FileUp },
]

export default function AdminSidebar() {
  const pathname = usePathname();

  const handleLogout = async () => {
    toast.loading("Logging out...");
    try {
      // Iron Session se logout karne ke liye API call karni hogi
      await fetch('/api/Bismillah786/logout', { method: 'POST' });
      toast.dismiss();
      toast.success("Logged out successfully.");
      window.location.href = "/Bismillah786/login";
    } catch (error) {
      toast.dismiss();
      toast.error("Failed to log out.");
    }
  };

  return (
    // Sidebar ko poori height di gayi hai taake woh scroll na ho
    <aside className="w-64 flex-shrink-0 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 p-6 flex flex-col h-screen">
      <div className="flex-shrink-0">
        <Link href="/Bismillah786" className="text-2xl font-bold text-brand-primary mb-8 block">
            PocketValue
        </Link>
      </div>
      <nav className="flex-grow overflow-y-auto">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link href={item.href} className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${ pathname === item.href ? "bg-brand-primary/10 text-brand-primary font-semibold" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700" }`}>
                <item.icon size={18} />
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mt-8 mb-2 px-4">Tools</h3>
        <ul className="space-y-2">
            {secondaryNavItems.map(item => (
                 <li key={item.href}>
                     <Link href={item.href} className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${ pathname === item.href ? "bg-brand-primary/10 text-brand-primary font-semibold" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700" }`}>
                        <item.icon size={18} />
                        <span>{item.label}</span>
                     </Link>
                 </li>
            ))}
        </ul>
      </nav>
      <div className="mt-auto border-t border-gray-200 dark:border-gray-700 pt-4 flex-shrink-0">
        <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
          <LogOut size={18} />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}