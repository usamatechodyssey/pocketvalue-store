// app/[slug]/page.tsx
// Upgraded for Next.js 15 + React 19 async params usage
// Uses Next.js Image and Link components, PortableText, and Sanity client/image helpers.

import React from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { PortableText } from "@portabletext/react";

import { client } from "@/sanity/lib/client";
import { GET_PAGE_QUERY } from "@/sanity/lib/queries";
import { urlFor } from "@/sanity/lib/image";

/**
 * Types
 */
interface Page {
  _id: string;
  title: string;
  body: any;
  // add other fields if your Sanity schema includes them (e.g., slug, excerpt, etc.)
}

interface PortableTextImage {
  _type: "image";
  asset: {
    _ref: string;
    _type: "reference";
  };
  alt?: string;
  // metadata fields if available
}

/**
 * Portable Text components using Next.js Image & Link
 * Ensure urlFor(value).width(...).quality(...).url() returns a string
 */
const ptComponents = {
  types: {
    image: ({ value }: { value: PortableTextImage }) => {
      if (!value?.asset?._ref) {
        return null;
      }

      // Build image URL from Sanity helper
      const src = urlFor(value).width(1200).quality(80).url() as unknown as string;

      // If src is falsy, return null to avoid Next/Image errors
      if (!src) return null;

      return (
        <figure className="my-8">
          <Image
            src={src}
            alt={value.alt || "Informational image"}
            loading="lazy"
            // Provide explicit width/height to satisfy Next/Image; you can adjust as needed
            width={1200}
            height={800}
            className="w-full h-auto rounded-lg shadow-lg border border-gray-200 dark:border-gray-700"
            // priority={false} // Uncomment if you want priority loading
          />
          {value.alt && (
            <figcaption className="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">
              {value.alt}
            </figcaption>
          )}
        </figure>
      );
    },
  },
  block: {
    h2: ({ children }: any) => (
      <h2 className="text-3xl font-bold mt-10 mb-4 text-gray-800 dark:text-gray-100 border-b border-gray-200 dark:border-gray-700 pb-2">
        {children}
      </h2>
    ),
    h3: ({ children }: any) => (
      <h3 className="text-2xl font-semibold mt-8 mb-3 text-gray-700 dark:text-gray-200">
        {children}
      </h3>
    ),
    blockquote: ({ children }: any) => (
      <blockquote className="border-l-4 border-brand-primary bg-gray-50 dark:bg-gray-800/50 p-4 my-6 text-gray-600 dark:text-gray-300 italic">
        {children}
      </blockquote>
    ),
  },
  list: {
    bullet: ({ children }: any) => (
      <ul className="list-disc list-inside my-4 space-y-2 text-gray-600 dark:text-gray-300">
        {children}
      </ul>
    ),
    number: ({ children }: any) => (
      <ol className="list-decimal list-inside my-4 space-y-2 text-gray-600 dark:text-gray-300">
        {children}
      </ol>
    ),
  },
  marks: {
    link: ({ value, children }: any) => {
      const href: string = value?.href || "";
      const isInternal = href.startsWith("/") || href.startsWith("#");
      if (isInternal) {
        return (
          <Link href={href} className="text-brand-primary font-semibold hover:underline">
            {children}
          </Link>
        );
      }
      return (
        <Link
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-brand-primary font-semibold hover:underline"
        >
          {children}
        </Link>
      );
    },
  },
};

/**
 * Props type per Next.js 15 async params convention.
 * params is a Promise that resolves to the real params object.
 */
type InfoPageProps = {
  params: Promise<{ slug: string }>;
  // If you also expect searchParams: Promise<{ [key: string]: string | string[] | undefined }>
  // you can add it here similarly.
};

/**
 * The page component (async) — awaits params because Next 15 makes params async
 */
export default async function InfoPage(props: InfoPageProps) {
  // Await the params to access slug
  const params = await props.params;
  const slug = params.slug;

  // Fetch page data from Sanity
  const pageData = await client.fetch<Page | null>(GET_PAGE_QUERY, { slug });

  if (!pageData) {
    // Next.js helper to render 404
    notFound();
  }

  return (
    <main className="w-full bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <article className="max-w-4xl mx-auto">
          <header className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-gray-900 dark:text-white">
              {pageData.title}
            </h1>
          </header>

          <div className="prose prose-lg lg:prose-xl max-w-none dark:prose-invert prose-p:text-gray-600 dark:prose-p:text-gray-300 prose-a:text-brand-primary prose-strong:text-gray-800 dark:prose-strong:text-gray-100">
            <PortableText value={pageData.body} components={ptComponents} />
          </div>
        </article>
      </div>
    </main>
  );
}
